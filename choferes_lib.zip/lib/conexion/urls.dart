
const SERVER_URL = 'https://crm.migente1.net:4580/tesa';
const PRE_URL = SERVER_URL + '/movilapi';
//const SERVER_URL = 'http://crm.migente1.net:85/tesa2';